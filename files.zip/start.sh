#!/bin/bash
set -e

echo "==> registry"
docker compose up -d registry
sleep 3

echo "==> build v1"
sed "s/__BUILD_TIME__/$(date -u +%Y-%m-%dT%H:%M:%SZ)/" app/html/index.html > app/html/index.tmp.html
mv app/html/index.tmp.html app/html/index.html
docker build -t localhost:5000/myapp:latest ./app

echo "==> push"
docker push localhost:5000/myapp:latest

echo "==> app + watchtower"
docker compose up -d app watchtower

echo ""
echo "Done."
echo "App  : http://localhost:8080"
echo "Logs : ./scripts/logs.sh"
echo "Bump : ./scripts/release.sh v2.0.0"
